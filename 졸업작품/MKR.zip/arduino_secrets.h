// Fill in  your WiFi networks SSID and password
#define SECRET_SSID "403"   // 와이파이 ID
#define SECRET_PASS "donttouch"  // 와이파이 비번

// Fill in the hostname of your AWS IoT broker 
#define SECRET_BROKER "a32lfpoii34xf0-ats.iot.ap-northeast-1.amazonaws.com" // 엔드포인트

// Fill in the boards public certificate
const char SECRET_CERTIFICATE[] = R"( // 인증서
-----BEGIN CERTIFICATE-----
MIICiDCCAXCgAwIBAgIVAP3nvLtyJrNRvizIW+riNwatH7CIMA0GCSqGSIb3DQEB
CwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t
IEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0yMTA2MDYwOTM0
MTlaFw00OTEyMzEyMzU5NTlaMBcxFTATBgNVBAMTDElvVFNtYXJ0QmVsbDBZMBMG
ByqGSM49AgEGCCqGSM49AwEHA0IABDN7tSsofWtJcmaf5zH/06CTxBWCoCCyIlwV
Kut/GlujpxXzGUuSBAbkPTaMlPxqJ2yYX1Ed9q28uloxAFpT78CjYDBeMB8GA1Ud
IwQYMBaAFKDym6zRsPp03FdP+Ar5WRCLKUeeMB0GA1UdDgQWBBSd9qISEwnu2uQP
49ThDh6UvpMRPDAMBgNVHRMBAf8EAjAAMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG
9w0BAQsFAAOCAQEARj5fdvkB+Bc3ZIskSOaaKE+Lx2ghi/i+z5gZopcYw1eot9OF
yibif/zB1x665wGBY6EQR38VTOMlJZhJwqg5DrDm0nhv+Bb1zOVw4JN6RitvFjJG
v5q7z7H47XMvanrnwKnZh/1XryOVBAIBH9mAdVgCaW1VuEooUM4v+bhpTErWJ4bC
EcvA9ubAkFFBFLMEWRG2WRMjmZjBWZciMqGl6pgzvIMg7ePanNAqhdBhTL1GQmDS
dfOGIoRfVsqd6dRvKeeOpsF444e7KoGjbawZ/uXX8bHjLNsqGj9GEnDHQjl5EZD6
kFqYXUjGOaJcfYXpk4/vMVimLEAQu7YClLVHVA==
-----END CERTIFICATE-----
)";
